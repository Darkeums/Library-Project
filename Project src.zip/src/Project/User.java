package Project;

import java.util.LinkedList;

public class User extends Person implements User_Procedures
{
    private int libraryCardNum;
    public static LinkedList<User> users=new LinkedList<>();

    public User(String name, int age, String gender, int libraryCardNum)
    {
        super(name, age, gender);
        this.libraryCardNum=libraryCardNum;
    }
    public User(User CopyConstructor)
    {
        super(CopyConstructor.getName(), CopyConstructor.getAge(), CopyConstructor.getGender());
        this.libraryCardNum=CopyConstructor.libraryCardNum;

    }

    public int getLibraryCardNum() {
        return libraryCardNum;
    }
    public void setLibraryCardNum(int libraryCardNum) {
        this.libraryCardNum = libraryCardNum;
    }

    @Override
    public String Check_Information() {
        return super.toString()+" "+"Library card number: "+libraryCardNum;
    }

    @Override
    public void SearchBookByTitle(String Title) {
        boolean flag=false;
        for (int i = 0; i < Book.Books.size(); i++) {
            Book book = Book.Books.get(i);
            if (book.getTitle().equals(Title)) {
                System.out.println("Found Book: " + book.toString());
                flag=true;
                break;

            }

        }
        if(flag==false){
            System.out.println("Book Not Found");
        }

    }


    @Override
    public void SearchBookByAuthor(String Name) {
        boolean flag2 = false;
        for (int i = 0; i < Book.Books.size(); i++) {
            Book book = Book.Books.get(i);
            if (book.getAuthor().equalsIgnoreCase(Name)) {
                System.out.println("Book found: " + book.getTitle());
                flag2 = true;
            }
        }
        if (flag2==false) {
            System.out.println("No books found for" + Name );
        }
    }

    @Override
    public void SearchBookByGenre(String Genre) {
        boolean flag3 = false;
        for (int i = 0; i < Book.Books.size(); i++) {
            Book book = Book.Books.get(i);
            if (book.getGenre().equalsIgnoreCase(Genre)) {
                System.out.println("Book found: " + book.getTitle());
                flag3 = true;
            }
        }
        if (flag3==false) {
            System.out.println("No books found for genre '" + Genre + "'.");
        }
    }
    //will allow the user to borrow a book
    //based on the title.
    @Override
    public void BorrowBook(String Title) {
        boolean bookexists = false;
        for (int i = 0; i < Book.Books.size(); i++) {
            Book book = Book.Books.get(i);
            //availability
            if (book.getTitle().equals(Title)) {
                bookexists = true;
                if(!book.getAvailability()){
                    System.out.println("Book is not available");
                    return;
                }
                //reserved
                if(book.getReserved()){
                    bookexists = true;
                    System.out.println("Book is already reserved");
                    return;
                }
                //non reserved
                bookexists = true;
                book.setAvailability(false);
                System.out.println("Book available and ready to be borrowed");
                return;
            }
        }
        if(bookexists==false)
        {
            System.out.println("Book doesn't exist");

        }

    }

    @Override
    public void ReturnBook(String Title) {
            boolean bookAvailable = false;
            for (int i = 0; i < Book.Books.size(); i++) {
                Book book = Book.Books.get(i);
                if (book.getTitle().equals(Title)) {
                    bookAvailable = true;
                    if(!book.getAvailability()){
                        System.out.println("Book is not borrowed");
                        return;
                    }
                    book.setAvailability(true);
                    System.out.println("book returned");
                    return;
                }
            }
    }

    @Override
    public void ReserveBook(String Title) {
            boolean bookAvailable = false;
            for (int i = 0; i < Book.Books.size(); i++) {
                Book book = Book.Books.get(i);
                if (book.getTitle().equals(Title)) {
                    bookAvailable = true;
                    if(!book.getAvailability()){
                        System.out.println("Book is not available");
                        return;
                    }
                    if(book.getReserved()){
                        System.out.println("Book is already reserved");
                        return;
                    }
                    book.setReserved(true);
                    System.out.println("book reserved");
                    return;
                }
            }
    }
}
