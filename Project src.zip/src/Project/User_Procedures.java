package Project;

public interface User_Procedures
{
    void SearchBookByTitle(String Title);
    void SearchBookByAuthor(String Name);
    void SearchBookByGenre(String Genre);
    void BorrowBook(String Title);
    void ReturnBook(String Title);
    void ReserveBook(String Title);
}
