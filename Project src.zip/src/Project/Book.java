package Project;
import java.util.LinkedList;
public class Book {
    private int ISBN;
    private String Title;
    private String Author;
    private String Genre;
    private Boolean Availability;
    private Boolean Reserved;
    public static LinkedList <Book> Books= new LinkedList<>();

    public Book()
    {

    }
    public Book(int ISBN, String Title, String Author, String Genre, boolean Availability, boolean Reserved)
    {
        this.ISBN=ISBN;
        this.Title=Title;
        this.Author=Author;
        this.Genre=Genre;
        this.Availability=Availability;
        this.Reserved=Reserved;
    }
    public Book(Book CopyConstructor)
    {
        this.ISBN= CopyConstructor.ISBN;
        this.Title=CopyConstructor.Title;
        this.Author=CopyConstructor.Author;
        this.Genre=CopyConstructor.Genre;
        this.Availability=CopyConstructor.Availability;
        this.Reserved=CopyConstructor.Reserved;
    }

    public int getISBN() {
        return ISBN;
    }

    public void setISBN(int ISBN) {
        this.ISBN = ISBN;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String author) {
        Author = author;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String genre) {
        Genre = genre;
    }

    public Boolean getAvailability() {
        return Availability;
    }

    public void setAvailability(Boolean availability) {
        Availability = availability;
    }

    public Boolean getReserved() {
        return Reserved;
    }

    public void setReserved(Boolean reserved) {
        Reserved = reserved;
    }
    public static LinkedList<Book> getBooks()
    {
        return Books;
    }

    @Override
    public String toString() {
        return "Title: "+Title+"ISBN: "+ISBN+"Author: "+Author+"Genre: "+Genre;
    }
}
