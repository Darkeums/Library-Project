package Project;

public interface Librarian_Procedures
{
    void SearchBookByTitle(String Title);
    void SearchBookByAuthor(String Name);
    void SearchBookByGenre(String Genre);
    void Add_User();
    void Add_Books();
}
