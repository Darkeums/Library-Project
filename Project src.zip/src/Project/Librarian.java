package Project;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Librarian extends Person implements Librarian_Procedures{
    private int employeeID;
    public static LinkedList<Librarian> librarian = new LinkedList<Librarian>();

    public Librarian(String Name, int Age, String Gender, int employeeID) {
        super(Name, Age, Gender);
        this.employeeID = employeeID;
    }

    public Librarian(Librarian librarian) {
        super(librarian.getName(), librarian.getAge(), librarian.getGender());
        this.employeeID = librarian.getEmployeeID();

    }

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public void AddLibrarian(Librarian L) {
        librarian.add(L);
    }

    @Override
    public String Check_Information() {

        return "Name: " + getName() + ", Age:" + getAge() + ", Gender: " + getGender() + ", employeeID: " + employeeID;

    }

    // SearchBookByTitle(String Title) will return the information of the
    // book if found based on the title. If not found, notify that the book
    // was not found.
    public void SearchBookByTitle(String Title) {
        boolean flag=false;
        for (int i = 0; i < Book.Books.size(); i++) {
            Book book = Book.Books.get(i);
            if (book.getTitle().equals(Title)) {
                System.out.println("Found Book: " + book.toString());
                flag=true;
                break;
                // idk if i should keep break;
            }

        }
        if(flag==false){
            System.out.println("Book Not Found");
        }

    }
    //SearchBookByAuthor (String Author) will return the title of all the
    //books based on the author if found. If not found, notify that the
    //books of that author do not exist.
    @Override
    public void SearchBookByAuthor(String Name) {
        boolean flag2 = false;
        for (int i = 0; i < Book.Books.size(); i++) {
            Book book = Book.Books.get(i);
            if (book.getAuthor().equalsIgnoreCase(Name)) {
                System.out.println("Book found: " + book.getTitle());
                flag2 = true;
            }
        }
        if (flag2==false) {
            System.out.println("No books found for" + Name );
        }
    }
    //SearchBookByGenre(String Genre) will return the title of all the
    //books based on the genre if found. If not found, notify that the
    //books of that genre do not exist.
    @Override
    public void SearchBookByGenre(String Genre) {
        boolean flag3 = false;
        for (int i = 0; i < Book.Books.size(); i++) {
            Book book = Book.Books.get(i);
            if (book.getGenre().equalsIgnoreCase(Genre)) {
                System.out.println("Book found: " + book.getTitle());
                flag3 = true;
            }
        }
        if (flag3==false) {
            System.out.println("No books found for genre '" + Genre + "'.");
        }
    }

    @Override
    public void Add_User() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Name: ");
        String name = sc.nextLine();
        System.out.println("Enter Age: ");
        int age;
        //exception part for age+ conditions:
        while(true)
        {
            try{
                System.out.println("Enter Age: ");
                age = sc.nextInt();
                if(age<18 || age>100)
                {
                    throw new IllegalArgumentException("Age must be between 18 and 100");
                }
                // if age is rational get out of loop
                break;
            } catch (IllegalArgumentException e){
                System.out.println(e.getMessage());
            }
        }
        System.out.println("Enter Gender: ");
        String gender = sc.nextLine();
        //add user info to the linked list by creating a new user and adding it
        int randomLibraryNum=0;
       boolean CardNumFound=false;
       do{
           randomLibraryNum=(int)(Math.random()*100000);
           CardNumFound=false;

           for(User user: User.users){
               if(user.getLibraryCardNum()==randomLibraryNum){
                   CardNumFound=true;
                   break;
               }
           }

       }while(CardNumFound);

       User u1= new User(name,age,gender,randomLibraryNum);
       User.users.add(u1);

        System.out.println("User has been added");
    }

    @Override
    public void Add_Books() {
        Scanner sc1= new Scanner(System.in);
        System.out.println("Enter number of books you wish to add");
        int numberOfBooks = sc1.nextInt();
        for (int i = 0; i < numberOfBooks; i++) {
            System.out.println("Add book information of:"+(i+1));

            System.out.println("Enter Title: ");
            String title = sc1.nextLine();
            System.out.println("Enter ISBN: ");
            int ISBN = sc1.nextInt();
            System.out.println("Enter Author: ");
            String author = sc1.nextLine();
            System.out.println("Enter Genre: ");
            String genre = sc1.nextLine();
            //had to add availability + reserved
            System.out.println("Availability:");
            boolean availability = sc1.nextBoolean();
            System.out.println("Reserved?");
            boolean reserved = sc1.nextBoolean();
            Book book= new Book(ISBN,title,author,genre,availability,reserved);
            Book.Books.add(book); //added book

        }
        System.out.println("Book(s) have been added");
    }
}

