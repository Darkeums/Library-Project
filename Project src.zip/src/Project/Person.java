package Project;

public abstract class Person {
    private String Name;
    private int Age;
    private String Gender;

    public Person(String Name, int Age, String Gender) {
        this.Name = Name;
        setAge(Age);
        this.Gender = Gender;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int age) {
        Age = Math.max(18, age);
        // Keeping it legal :)
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    @Override
    public String toString() {
        return "Name: " + Name + " Age: " + Age + " Gender: " + Gender;
    }

    public abstract String Check_Information();
}

