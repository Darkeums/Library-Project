import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import Project.Book;

import java.io.*;

import Project.User;
import javax.imageio.ImageIO;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.event.ActionListener;
import java.util.LinkedList;

import Project.Librarian;


import static Project.Librarian.librarian;
public class mainUI extends javax.swing.JFrame {
    private JButton button1;
    private JPanel panel1;
    private Librarian L1;
    private User U1;
    private Book B1;
    private Book B2;
    private Book B3;

    static JLabel label1=new JLabel();



    public mainUI() {
        Runtime.getRuntime().addShutdownHook(new Thread(this::writeDataToFile));
        L1 = new Librarian("Jana", 20, "F", 123);
        Librarian.librarian.add(L1);
        U1 = new User ("Rick", 19, "M", 234);
        User.users.add(U1);
        B1= new Book(1111, "Apple", "Mark Twain", "Murder", true, false);
        Book.Books.add(B1);
        B2 = new Book(1112, "Grape", "Mark Twain", "Murder", true, true);
        Book.Books.add(B2);
        B3 = new Book(1113, "Seafood", "Charles Dickens", "Educational", true, false);
        Book.Books.add(B3);

        setTitle("Library System"); //title of gui window
        setDefaultCloseOperation(EXIT_ON_CLOSE); //if u click on "X" it ends the operation
        setSize(800, 600); // size of the panel
        setLocationRelativeTo(null); //window is nonrelatve= stays in the center of the screen
        JPanel panel = new JPanel(new BorderLayout()); //BorderLayout
        panel.setBackground(Color.GRAY);
        BufferedImage backgroundImage = null;
        try {
            backgroundImage = ImageIO.read(new File("C:\\Users\\janaj\\OneDrive\\Pictures\\background.jpg.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Create a JLabel with the background image
        assert backgroundImage != null;
        JLabel backgroundLabel = new JLabel(new ImageIcon(backgroundImage));
        backgroundLabel.setLayout(new GridLayout(0, 1));

        // Welcome message
        JLabel welcomeLabel = new JLabel("Welcome to Haigazian Library");
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER); // keep text centered
        backgroundLabel.add(welcomeLabel, BorderLayout.NORTH);

        // Message
        JLabel messageLabel = new JLabel("Please log in accordingly: ");
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        backgroundLabel.add(messageLabel, BorderLayout.CENTER);

        // created another Panel for buttons
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2)); // grid for the buttons
        buttonPanel.setBackground(Color.white);

        // Librarian button
        JButton librarianButton = new JButton("Librarian");
        librarianButton.addActionListener((ActionEvent e) -> {
            LibrarianPanel librarianPanel = new LibrarianPanel();
            backgroundLabel.removeAll();
            backgroundLabel.add(librarianPanel, BorderLayout.CENTER);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        });
        buttonPanel.add(librarianButton);


        // User button
        JButton userButton = new JButton("User");
        userButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UserPanel userPanel = new UserPanel();
                backgroundLabel.removeAll();
                backgroundLabel.add(userPanel, BorderLayout.CENTER);
                backgroundLabel.revalidate();
                backgroundLabel.repaint();
            }
        });
        buttonPanel.add(userButton);
        backgroundLabel.add(buttonPanel, BorderLayout.SOUTH);
        setContentPane(backgroundLabel);
        setVisible(true);
        try{
            readDataFromFile("librarian.txt", Librarian.librarian);
            readDataFromFile("users.txt", User.users);
            readDataFromFile("books.txt", Book.Books);
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    @SuppressWarnings("unchecked")
    private void writeDataToFile() {
        try{
            writeLinkedListToFile("librarian.txt", Librarian.librarian);
            writeLinkedListToFile("users.txt",User.users);
            writeLinkedListToFile("books.txt",Book.Books);
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    private <T> void writeLinkedListToFile(String fileName, LinkedList<T> list) throws IOException {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
            for (T item : list) {
                outputStream.writeObject(item);
            }
        }
    }
    @SuppressWarnings("unchecked")
    private <T> void readDataFromFile(String fileName, LinkedList<T> list) throws IOException {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(fileName))) {
            while (true){
                try{
                    T item=(T) inputStream.readObject();
                    list.add(item);
                }catch (EOFException e){
                    break;
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(mainUI::new); //basically the panels, buttons and all only get created when u run the program
    }
    class UserPanel extends JPanel {
        public UserPanel(){
            setLayout(new BorderLayout());
            setTitle("User Log In");
            JLabel LogIn = new JLabel("Enter Library Card Number");
            LogIn.setHorizontalAlignment(SwingConstants.CENTER); // keep text centered
            add(LogIn, BorderLayout.NORTH);
            JButton Confirm = new JButton("Confirm");
            JTextField textField = new JTextField();
            textField.setHorizontalAlignment(SwingConstants.CENTER);
            add(textField, BorderLayout.SOUTH);
            add(Confirm, BorderLayout.EAST);
            Confirm.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String s = textField.getText();
                    try {
                        int n = Integer.parseInt(s);
                        for (int i = 0; i < User.users.size(); i++) {
                            if (n == User.users.get(i).getLibraryCardNum()) {
                                // Open new panel
                                // actually just clearing the existing panel is fine
                                mainUI.this.getContentPane().removeAll();

                                JPanel loggedInPanel2 = new JPanel(new BorderLayout());
                                JLabel welcomeLabel = new JLabel("Welcome to the Library System!");

                                loggedInPanel2.add(welcomeLabel,BorderLayout.NORTH);
                                // Create panel for librarian functions
                                JPanel userFunctionsPanel = new JPanel(new GridLayout(2, 2));
                                JButton checkInformationButton = new JButton("Check Information");
                                JButton searchByTitleButton = new JButton("Search By Title");
                                JButton searchByAuthorButton = new JButton("Search By Author");
                                JButton searchByGenreButton = new JButton("Search By Date");
                                JButton borrowBookButton = new JButton("Borrow Book");
                                JButton returnBookButton = new JButton("Return Book");
                                JButton reserveBookButton = new JButton("Reserve Book");
                                int j = i;
                                checkInformationButton.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        JOptionPane.showMessageDialog(mainUI.this, User.users.get(j).Check_Information());
                                    }
                                });
                                searchByTitleButton.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                        JTextField titleField = new JTextField();
                                        inputPanel.add(new JLabel("Enter title:"));
                                        inputPanel.add(titleField);
                                        JButton searchButton = new JButton("Search");
                                        searchButton.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                String title = titleField.getText();
                                                boolean found= false;
                                                for(int i=0;i<Book.Books.size();i++){
                                                    if(title.equalsIgnoreCase(Book.Books.get(i).getTitle())){
                                                        JOptionPane.showMessageDialog(mainUI.this,"Book found");
                                                        break;
                                                    }
                                                    else {
                                                        JOptionPane.showMessageDialog(mainUI.this,"Book not found");
                                                    }
                                                }

                                            }
                                        });
                                        JPanel panel= new JPanel(new BorderLayout());
                                        panel.add(inputPanel, BorderLayout.CENTER);
                                        panel.add(searchButton, BorderLayout.SOUTH);
                                        JOptionPane.showMessageDialog(null,panel);


                                    }
                                });
                                searchByAuthorButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        //searchbyauthor functionality
                                        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                        JTextField AuthorField = new JTextField();
                                        inputPanel.add(new JLabel("Enter author:"));
                                        inputPanel.add(AuthorField);
                                        JButton searchButton = new JButton("Search");
                                        searchButton.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                String author = AuthorField.getText();
                                                String titles="";
                                                boolean found= false;
                                                for(int i=0;i<Book.Books.size();i++){
                                                    if(author.equalsIgnoreCase(Book.Books.get(i).getAuthor())){
                                                        String[] arr= new String[Book.Books.size()];
                                                        found=true;
                                                        titles=titles+Book.Books.get(i).getTitle()+"\n";

                                                    }
                                                }
                                                if(found){

                                                    JOptionPane.showMessageDialog(mainUI.this,"Books found"+titles);

                                                }else{
                                                    JOptionPane.showMessageDialog(mainUI.this,"No Book not found by author: "+author);
                                                }
                                            }
                                        });
                                        JPanel panel = new JPanel(new BorderLayout());
                                        panel.add(inputPanel, BorderLayout.CENTER);
                                        panel.add(searchButton, BorderLayout.SOUTH);
                                        JOptionPane.showMessageDialog(null, panel);

                                    }

                                });
                                searchByGenreButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        //searchbyauthor functionality
                                        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                        JTextField GenreField = new JTextField();
                                        inputPanel.add(new JLabel("Enter genre:"));
                                        inputPanel.add(GenreField);
                                        JButton searchButton = new JButton("Search");
                                        searchButton.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                String genre = GenreField.getText();
                                                String titles="";
                                                boolean found= false;
                                                for(int i=0;i<Book.Books.size();i++){
                                                    if(genre.equalsIgnoreCase(Book.Books.get(i).getGenre())){
                                                        String[] arr= new String[Book.Books.size()];
                                                        found=true;
                                                        titles=titles+Book.Books.get(i).getTitle()+"\n";

                                                    }
                                                }
                                                if(found){

                                                    JOptionPane.showMessageDialog(mainUI.this,"Books found"+titles);

                                                }else{
                                                    JOptionPane.showMessageDialog(mainUI.this,"No Book not found by author: "+genre);
                                                }
                                            }
                                        });
                                        JPanel panel = new JPanel(new BorderLayout());
                                        panel.add(inputPanel, BorderLayout.CENTER);
                                        panel.add(searchButton, BorderLayout.SOUTH);
                                        JOptionPane.showMessageDialog(null, panel);

                                    }

                                });
                                borrowBookButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                        JTextField titleField = new JTextField();
                                        inputPanel.add(new JLabel("Enter title of book you want to borrow:"));
                                        inputPanel.add(titleField);
                                        JButton borrowButton = new JButton("Borrow");
                                        borrowButton.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                String title = titleField.getText();
                                                boolean found= false;
                                                for(int i=0;i<Book.Books.size();i++){
                                                    if(title.equalsIgnoreCase(Book.Books.get(i).getTitle())){
                                                        found=true;
                                                        if(Book.Books.get(i).getAvailability()){
                                                            Book.Books.get(i).setAvailability(false);
                                                            JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" borrowed successfully!");
                                                        }
                                                        else{
                                                            JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" cannot be borrowed!");
                                                        }
                                                        break;
                                                    }
                                                }
                                                if(!found){
                                                    JOptionPane.showMessageDialog(mainUI.this,"Book not found");
                                                }
                                            }
                                        });
                                        Panel panel = new Panel(new BorderLayout());
                                        panel.add(inputPanel, BorderLayout.CENTER);
                                        panel.add(borrowButton, BorderLayout.SOUTH);
                                        JOptionPane.showMessageDialog(null, panel);
                                    }
                                });
                                returnBookButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        //returnBook functionality
                                        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                        JTextField titleField = new JTextField();
                                        inputPanel.add(new JLabel("Enter title of book you want to return:"));
                                        inputPanel.add(titleField);
                                        JButton returnButton = new JButton("Return");
                                        returnButton.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                String title = titleField.getText();
                                                boolean found= false;

                                                for(int i=0;i<Book.Books.size();i++){
                                                    if(title.equalsIgnoreCase(Book.Books.get(i).getTitle())){
                                                        found=true;
                                                        if(!Book.Books.get(i).getAvailability()){
                                                            Book.Books.get(i).setAvailability(true);
                                                            JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" returned successfully!");
                                                        }else{
                                                            JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" cannot be returned!");
                                                        }
                                                        break;
                                                    }
                                                }
                                                if(!found){
                                                    JOptionPane.showMessageDialog(mainUI.this,"Book not found");
                                                }
                                            }
                                        });
                                        Panel panel = new Panel(new BorderLayout());
                                        panel.add(inputPanel, BorderLayout.CENTER);
                                        panel.add(returnButton, BorderLayout.SOUTH);
                                        JOptionPane.showMessageDialog(null, panel);
                                    }
                                });
                                reserveBookButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                        JTextField titleField = new JTextField();
                                        inputPanel.add(new JLabel("Enter title of book you want to reserve:"));
                                        inputPanel.add(titleField);
                                        JButton reserveButton = new JButton("Reserve");

                                        reserveButton.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                String title = titleField.getText();
                                                boolean found= false;
                                                for(int i=0;i<Book.Books.size();i++){
                                                    if(title.equalsIgnoreCase(Book.Books.get(i).getTitle())){
                                                        found=true;
                                                        if(!Book.Books.get(i).getReserved()&&Book.Books.get(i).getAvailability()){
                                                            Book.Books.get(i).setReserved(true);
                                                            JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" reserved successfully!");
                                                        } else{
                                                            JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" cannot be reserved!");
                                                        }
                                                        break;
                                                    }
                                                }
                                                if(!found){
                                                    JOptionPane.showMessageDialog(mainUI.this,"Book not found");
                                                }
                                            }
                                        });
                                        Panel panel = new Panel(new BorderLayout());
                                        panel.add(inputPanel, BorderLayout.CENTER);
                                        panel.add(reserveButton, BorderLayout.SOUTH);
                                        JOptionPane.showMessageDialog(null, panel);

                                    }
                                });
                                userFunctionsPanel.add(checkInformationButton);
                                userFunctionsPanel.add(searchByTitleButton);
                                userFunctionsPanel.add(searchByAuthorButton);
                                userFunctionsPanel.add(searchByGenreButton);
                                userFunctionsPanel.add(borrowBookButton);
                                userFunctionsPanel.add(returnBookButton);
                                userFunctionsPanel.add(reserveBookButton);
                                loggedInPanel2.add(userFunctionsPanel,BorderLayout.CENTER);
                                JButton logoutButton = new JButton("Logout");
                                loggedInPanel2.add(logoutButton,BorderLayout.SOUTH);
                                logoutButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        mainUI.this.dispose();

                                        new mainUI();
                                    }
                                });

                                // Add the new panel to the frame
                                mainUI.this.getContentPane().add(loggedInPanel2);

                                // Revalidate and repaint the frame
                                mainUI.this.revalidate();
                                mainUI.this.repaint();
                                // JOptionPane.showMessageDialog(mainUI.this, "Employee ID Found");

                                break;
                            } else if (i == User.users.size() - 1 && n != User.users.get(i).getLibraryCardNum()) {

                                // Display error message
                                JOptionPane.showMessageDialog(mainUI.this, "Invalid Card Number", "Error", JOptionPane.ERROR_MESSAGE);
                            }

                        }


                    } catch (NumberFormatException ex) {
                        // Display error message for invalid input
                        JOptionPane.showMessageDialog(mainUI.this, "The Card Number should be an integer", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });}}


    class LibrarianPanel extends JPanel {
        public LibrarianPanel() {

            setLayout(new BorderLayout());
            setTitle("Librarian Log In");
            JLabel LogIn = new JLabel("Enter EmployeeID");
            LogIn.setHorizontalAlignment(SwingConstants.CENTER); // keep text centered
            add(LogIn, BorderLayout.NORTH);

            JButton Confirm = new JButton("Confirm");
            JTextField textField = new JTextField();
            textField.setHorizontalAlignment(SwingConstants.CENTER);
            add(textField, BorderLayout.SOUTH);
            add(Confirm, BorderLayout.EAST);
            Confirm.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String s = textField.getText();

                    try {
                        int n = Integer.parseInt(s);
                        // Librarian l = new Librarian("x", 20, "M", n);
                        for (int i = 0; i < Librarian.librarian.size(); i++) {
                            if (n == Librarian.librarian.get(i).getEmployeeID()) {
                                // Open new panel
                                // actually just clearing the existing panel is fine
                                mainUI.this.getContentPane().removeAll();

                                JPanel loggedInPanel2 = new JPanel(new BorderLayout());
                                JLabel welcomeLabel = new JLabel("Welcome to the Library System!");

                                loggedInPanel2.add(welcomeLabel,BorderLayout.NORTH);
                                // Create panel for librarian functions
                                JPanel librarianFunctionsPanel = new JPanel(new GridLayout(3, 3));
                                JButton addLibrarianButton = new JButton("Add Librarian");
                                JButton addUserButton = new JButton("Add User");
                                JButton checkInformationButton = new JButton("Check Information");
                                JButton searchByTitleButton = new JButton("Search By Title");
                                JButton searchByAuthorButton = new JButton("Search By Author");
                                JButton searchByGenreButton = new JButton("Search By Genre");
                                JButton borrowBookButton = new JButton("Borrow Book");
                                JButton returnBookButton = new JButton("Return Book");
                                JButton reserveBookButton = new JButton("Reserve Book");
                                int j = i;

                                //Add librarian
                                addLibrarianButton.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        //librarian functionality
                                        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
                                        JTextField nameField = new JTextField();
                                        JTextField ageField = new JTextField();
                                        JTextField genderField = new JTextField();
                                        JTextField employeeIDField = new JTextField();
                                        inputPanel.add(new JLabel("Name:"));
                                        inputPanel.add(nameField);
                                        inputPanel.add(new JLabel("Age:"));
                                        inputPanel.add(ageField);
                                        inputPanel.add(new JLabel("Gender:"));
                                        inputPanel.add(genderField);
                                        inputPanel.add(new JLabel("Employee ID:"));
                                        inputPanel.add(employeeIDField);
                                        int result = JOptionPane.showConfirmDialog(mainUI.this, inputPanel,
                                                "Enter Librarian Details", JOptionPane.OK_CANCEL_OPTION);
                                        if (result == JOptionPane.OK_OPTION) {
                                            // Get input values
                                            String name = nameField.getText();
                                            int age = Integer.parseInt(ageField.getText());
                                            String gender = genderField.getText();
                                            int employeeID = Integer.parseInt(employeeIDField.getText());

                                            // Create a new librarian object
                                            Librarian newLibrarian = new Librarian(name, age, gender, employeeID);

                                            // Add the new librarian to the linked list
                                            librarian.add(newLibrarian);

                                            // Display success message
                                            JOptionPane.showMessageDialog(mainUI.this, "Librarian added successfully!");
                                        }

                                    }
                                });
                                //Add user
                                addUserButton.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        //add user functionality
                                        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
                                        JTextField nameField = new JTextField();
                                        JTextField ageField = new JTextField();
                                        JTextField genderField = new JTextField();
                                        JTextField libraryCardNumberField = new JTextField();
                                        inputPanel.add(new JLabel("Name:"));
                                        inputPanel.add(nameField);
                                        inputPanel.add(new JLabel("Age:"));
                                        inputPanel.add(ageField);
                                        inputPanel.add(new JLabel("Gender:"));
                                        inputPanel.add(genderField);
                                        inputPanel.add(new JLabel("Library Card Number:"));
                                        inputPanel.add(libraryCardNumberField);
                                        int result = JOptionPane.showConfirmDialog(mainUI.this, inputPanel,
                                                "Enter User Details", JOptionPane.OK_CANCEL_OPTION);
                                        if (result == JOptionPane.OK_OPTION) {
                                            // Get input values
                                            String name = nameField.getText();
                                            int age = Integer.parseInt(ageField.getText());
                                            String gender = genderField.getText();
                                            int libraryCardNumber = Integer.parseInt(libraryCardNumberField.getText());

                                            // Create a new user object
                                            User newUser = new User(name, age, gender, libraryCardNumber);

                                            // Add the new user to the linked list
                                            User.users.add(newUser);

                                            // Display success message
                                            JOptionPane.showMessageDialog(mainUI.this, "User added successfully!");
                                        }

                                    }
                                });
                                checkInformationButton.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        JOptionPane.showMessageDialog(mainUI.this, Librarian.librarian.get(j).Check_Information());
                                    }
                                });
                                //search by title
                                searchByTitleButton.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                        JTextField titleField = new JTextField();
                                        inputPanel.add(new JLabel("Enter title:"));
                                        inputPanel.add(titleField);
                                        JButton searchButton = new JButton("Search");
                                        searchButton.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                String title = titleField.getText();
                                                boolean found= false;
                                                for(int i=0;i<Book.Books.size();i++){
                                                    if(title.equalsIgnoreCase(Book.Books.get(i).getTitle())){
                                                        JOptionPane.showMessageDialog(mainUI.this,"Book found");
                                                        break;
                                                    }
                                                    else {
                                                        JOptionPane.showMessageDialog(mainUI.this,"Book not found");
                                                    }
                                                }

                                            }
                                        });
                                        JPanel panel= new JPanel(new BorderLayout());
                                        panel.add(inputPanel, BorderLayout.CENTER);
                                        panel.add(searchButton, BorderLayout.SOUTH);
                                        JOptionPane.showMessageDialog(null,panel);


                                    }
                                });
                                searchByAuthorButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        //searchbyauthor functionality
                                        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                        JTextField AuthorField = new JTextField();
                                        inputPanel.add(new JLabel("Enter author:"));
                                        inputPanel.add(AuthorField);
                                        JButton searchButton = new JButton("Search");
                                        searchButton.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                String author = AuthorField.getText();
                                                String titles="";
                                                boolean found= false;
                                                for(int i=0;i<Book.Books.size();i++){
                                                    if(author.equalsIgnoreCase(Book.Books.get(i).getAuthor())){
                                                        String[] arr= new String[Book.Books.size()];
                                                        found=true;
                                                        titles=titles+Book.Books.get(i).getTitle()+"\n";

                                                    }
                                                }
                                                if(found){

                                                   JOptionPane.showMessageDialog(mainUI.this,"Books found"+titles);

                                                }else{
                                                    JOptionPane.showMessageDialog(mainUI.this,"No Book not found by author: "+author);
                                                }
                                            }
                                        });
                                        JPanel panel = new JPanel(new BorderLayout());
                                        panel.add(inputPanel, BorderLayout.CENTER);
                                        panel.add(searchButton, BorderLayout.SOUTH);
                                        JOptionPane.showMessageDialog(null, panel);

                                    }

                                });
                                searchByGenreButton.addActionListener(new ActionListener() {
                                    @Override
                                            public void actionPerformed(ActionEvent e) {
                                                //searchbyauthor functionality
                                                JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                                JTextField GenreField = new JTextField();
                                                inputPanel.add(new JLabel("Enter genre:"));
                                                inputPanel.add(GenreField);
                                                JButton searchButton = new JButton("Search");
                                                searchButton.addActionListener(new ActionListener() {
                                                    @Override
                                                    public void actionPerformed(ActionEvent e) {
                                                        String genre = GenreField.getText();
                                                        String titles="";
                                                        boolean found= false;
                                                        for(int i=0;i<Book.Books.size();i++){
                                                            if(genre.equalsIgnoreCase(Book.Books.get(i).getGenre())){
                                                                String[] arr= new String[Book.Books.size()];
                                                                found=true;
                                                                titles=titles+Book.Books.get(i).getTitle()+"\n";

                                                            }
                                                        }
                                                        if(found){

                                                            JOptionPane.showMessageDialog(mainUI.this,"Books found"+titles);

                                                        }else{
                                                            JOptionPane.showMessageDialog(mainUI.this,"No Book not found by author: "+genre);
                                                        }
                                                    }
                                                });
                                                JPanel panel = new JPanel(new BorderLayout());
                                                panel.add(inputPanel, BorderLayout.CENTER);
                                                panel.add(searchButton, BorderLayout.SOUTH);
                                                JOptionPane.showMessageDialog(null, panel);

                                            }

                                        });
                                 borrowBookButton.addActionListener(new ActionListener() {
                                     @Override
                                     public void actionPerformed(ActionEvent e) {
                                         //borrowBook functionality
                                         JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                         JTextField titleField = new JTextField();
                                         inputPanel.add(new JLabel("Enter title of book you want to borrow:"));
                                         inputPanel.add(titleField);
                                         JButton borrowButton = new JButton("Borrow");
                                         borrowButton.addActionListener(new ActionListener() {
                                             @Override
                                             public void actionPerformed(ActionEvent e) {
                                                 String title = titleField.getText();
                                                 boolean found= false;
                                                 for(int i=0;i<Book.Books.size();i++){
                                                     if(title.equalsIgnoreCase(Book.Books.get(i).getTitle())){
                                                         found=true;
                                                         if(Book.Books.get(i).getAvailability()){
                                                             Book.Books.get(i).setAvailability(false);
                                                             JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" borrowed successfully!");
                                                         }
                                                         else{
                                                             JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" cannot be borrowed!");
                                                         }
                                                         break;
                                                     }
                                                 }
                                                 if(!found){
                                                     JOptionPane.showMessageDialog(mainUI.this,"Book not found");
                                                 }
                                             }
                                         });
                                         Panel panel = new Panel(new BorderLayout());
                                         panel.add(inputPanel, BorderLayout.CENTER);
                                         panel.add(borrowButton, BorderLayout.SOUTH);
                                         JOptionPane.showMessageDialog(null, panel);
                                     }
                                 });
                                 returnBookButton.addActionListener(new ActionListener() {
                                     @Override
                                     public void actionPerformed(ActionEvent e) {
                                         //returnBook functionality
                                         JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                         JTextField titleField = new JTextField();
                                         inputPanel.add(new JLabel("Enter title of book you want to return:"));
                                         inputPanel.add(titleField);
                                         JButton returnButton = new JButton("Return");
                                         returnButton.addActionListener(new ActionListener() {
                                             @Override
                                             public void actionPerformed(ActionEvent e) {
                                                 String title = titleField.getText();
                                                 boolean found= false;

                                                 for(int i=0;i<Book.Books.size();i++){
                                                     if(title.equalsIgnoreCase(Book.Books.get(i).getTitle())){
                                                         found=true;
                                                         if(!Book.Books.get(i).getAvailability()){
                                                             Book.Books.get(i).setAvailability(true);
                                                             JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" returned successfully!");
                                                         }else{
                                                             JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" cannot be returned!");
                                                         }
                                                         break;
                                                     }
                                                 }
                                                 if(!found){
                                                     JOptionPane.showMessageDialog(mainUI.this,"Book not found");
                                                 }
                                             }
                                         });
                                         Panel panel = new Panel(new BorderLayout());
                                         panel.add(inputPanel, BorderLayout.CENTER);
                                         panel.add(returnButton, BorderLayout.SOUTH);
                                         JOptionPane.showMessageDialog(null, panel);
                                     }
                                 });
                                 reserveBookButton.addActionListener(new ActionListener() {
                                     @Override
                                     public void actionPerformed(ActionEvent e) {
                                         //reserveBook functionality
                                         JPanel inputPanel = new JPanel(new GridLayout(2, 2));
                                         JTextField titleField = new JTextField();
                                         inputPanel.add(new JLabel("Enter title of book you want to reserve:"));
                                         inputPanel.add(titleField);
                                         JButton reserveButton = new JButton("Reserve");

                                         reserveButton.addActionListener(new ActionListener() {
                                             @Override
                                             public void actionPerformed(ActionEvent e) {
                                                 String title = titleField.getText();
                                                 boolean found= false;
                                                 for(int i=0;i<Book.Books.size();i++){
                                                     if(title.equalsIgnoreCase(Book.Books.get(i).getTitle())){
                                                         found=true;
                                                         if(!Book.Books.get(i).getReserved()&&Book.Books.get(i).getAvailability()){
                                                             Book.Books.get(i).setReserved(true);
                                                             JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" reserved successfully!");
                                                         } else{
                                                             JOptionPane.showMessageDialog(mainUI.this,"Book "+title+" cannot be reserved!");
                                                         }
                                                         break;
                                                     }
                                                 }
                                                 if(!found){
                                                     JOptionPane.showMessageDialog(mainUI.this,"Book not found");
                                                 }
                                             }
                                         });
                                         Panel panel = new Panel(new BorderLayout());
                                         panel.add(inputPanel, BorderLayout.CENTER);
                                         panel.add(reserveButton, BorderLayout.SOUTH);
                                         JOptionPane.showMessageDialog(null, panel);

                                     }
                                 });
                                librarianFunctionsPanel.add(addLibrarianButton);
                                librarianFunctionsPanel.add(addUserButton);
                                librarianFunctionsPanel.add(checkInformationButton);
                                librarianFunctionsPanel.add(searchByTitleButton);
                                librarianFunctionsPanel.add(searchByAuthorButton);
                                librarianFunctionsPanel.add(searchByGenreButton);
                                librarianFunctionsPanel.add(borrowBookButton);
                                librarianFunctionsPanel.add(returnBookButton);
                                librarianFunctionsPanel.add(reserveBookButton);
                                loggedInPanel2.add(librarianFunctionsPanel,BorderLayout.CENTER);
                                JButton logoutButton = new JButton("Logout");
                                loggedInPanel2.add(logoutButton,BorderLayout.SOUTH);

                                logoutButton.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        mainUI.this.dispose();

                                        new mainUI();
                                    }
                                });

                                // Add the new panel to the frame
                                mainUI.this.getContentPane().add(loggedInPanel2);

                                // Revalidate and repaint the frame
                                mainUI.this.revalidate();
                                mainUI.this.repaint();
                                // JOptionPane.showMessageDialog(mainUI.this, "Employee ID Found");

                                break;
                            } else if (i == Librarian.librarian.size() - 1 && n != Librarian.librarian.get(i).getEmployeeID()) {

                                // Display error message
                                JOptionPane.showMessageDialog(mainUI.this, "Invalid Employee ID", "Error", JOptionPane.ERROR_MESSAGE);
                            }

                        }


                    } catch (NumberFormatException ex) {
                        // Display error message for invalid input
                        JOptionPane.showMessageDialog(mainUI.this, "The Employee ID should be an integer", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                }
            });


        }

    }


}